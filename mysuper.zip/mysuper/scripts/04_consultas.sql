-- 1
SELECT * FROM Produtos;

-- 2 
SELECT nome, preco FROM Produtos;

-- 3 
SELECT nome, quantidade_estoque
FROM Produtos
WHERE quantidade_estoque < 50;

-- 4 
SELECT nome, pontos_fidelidade
FROM Clientes
WHERE pontos_fidelidade > 100;

-- 5 
SELECT nome, cargo, salario
FROM Funcionarios
ORDER BY salario DESC;

-- 6 
SELECT *
FROM Produtos
WHERE id_categoria = 5;

-- 7 
SELECT *
FROM Vendas
WHERE total > 100;

-- 8 
SELECT *
FROM Produtos
WHERE nome LIKE '%LG%';

-- 9 
SELECT *
FROM Clientes
ORDER BY nome;

-- 10 
SELECT nome, preco
FROM Produtos
WHERE preco BETWEEN 5 AND 100;


-- 1 
SELECT Produtos.nome, Categorias.nome
FROM Produtos
JOIN Categorias
ON Produtos.id_categoria = Categorias.id_categoria;

-- 2 
SELECT Produtos.nome, Fornecedores.nome
FROM Produtos
JOIN Fornecedores
ON Produtos.id_fornecedor = Fornecedores.id_fornecedor;

-- 3 
SELECT Vendas.id_venda, Clientes.nome
FROM Vendas
JOIN Clientes
ON Vendas.id_cliente = Clientes.id_cliente;

-- 4 
SELECT Vendas.id_venda, Funcionarios.nome
FROM Vendas
JOIN Funcionarios
ON Vendas.id_funcionario = Funcionarios.id_funcionario;

-- 5
SELECT Produtos.nome, Filiais.nome
FROM Produtos
JOIN Filiais
ON Produtos.id_filial = Filiais.id_filial;

-- 6 
SELECT ItensVenda.quantidade, Produtos.nome
FROM ItensVenda
JOIN Produtos
ON ItensVenda.id_produto = Produtos.id_produto;

-- 7 
SELECT Compras.id_compra, Fornecedores.nome
FROM Compras
JOIN Fornecedores
ON Compras.id_fornecedor = Fornecedores.id_fornecedor;

-- 8
SELECT Funcionarios.nome, Filiais.nome
FROM Funcionarios
JOIN Filiais
ON Funcionarios.id_filial = Filiais.id_filial;

-- 9 
SELECT Clientes.nome, Vendas.total
FROM Clientes
JOIN Vendas
ON Clientes.id_cliente = Vendas.id_cliente;

-- 10 
SELECT Vendas.id_venda, Produtos.nome
FROM ItensVenda
JOIN Produtos
ON ItensVenda.id_produto = Produtos.id_produto
JOIN Vendas
ON ItensVenda.id_venda = Vendas.id_venda;


-- 1 
SELECT id_categoria, COUNT(*)
FROM Produtos
GROUP BY id_categoria;

-- 2 
SELECT id_cliente, SUM(total)
FROM Vendas
GROUP BY id_cliente;

-- 3
SELECT cargo, AVG(salario)
FROM Funcionarios
GROUP BY cargo;

-- 4 
SELECT id_filial, COUNT(*)
FROM Funcionarios
GROUP BY id_filial;

--- 5 
SELECT id_filial, SUM(total)
FROM Vendas
GROUP BY id_filial;

-- 6 
SELECT id_fornecedor, COUNT(*)
FROM Produtos
GROUP BY id_fornecedor;

-- 7 
SELECT id_fornecedor, SUM(total)
FROM Compras
GROUP BY id_fornecedor;

-- 8 
SELECT id_categoria, AVG(preco)
FROM Produtos
GROUP BY id_categoria;

-- 9 
SELECT nome, SUM(pontos_fidelidade)
FROM Clientes
GROUP BY nome;

-- 10 
SELECT id_produto, SUM(quantidade)
FROM ItensVenda
GROUP BY id_produto;


-- 1 
SELECT COUNT(*) FROM Produtos;

-- 2 
SELECT SUM(quantidade_estoque)
FROM Produtos;

-- 3 
SELECT AVG(preco)
FROM Produtos;

-- 4 
SELECT MAX(preco)
FROM Produtos;

-- 5 
SELECT MIN(preco)
FROM Produtos;

-- 6 
SELECT COUNT(*)
FROM Vendas;

-- 7 
SELECT SUM(total)
FROM Vendas;

-- 8 
SELECT AVG(salario)
FROM Funcionarios;

-- 9 
SELECT MAX(salario)
FROM Funcionarios;

-- 10 
SELECT MIN(salario)
FROM Funcionarios;


-- 1 
SELECT *
FROM Produtos
WHERE preco = (
   SELECT MAX(preco)
   FROM Produtos
);

-- 2 
SELECT *
FROM Produtos
WHERE preco = (
   SELECT MIN(preco)
   FROM Produtos
);

-- 3 
SELECT *
FROM Clientes
WHERE pontos_fidelidade > (
   SELECT AVG(pontos_fidelidade)
   FROM Clientes
);

-- 4 
SELECT *
FROM Funcionarios
WHERE salario = (
   SELECT MAX(salario)
   FROM Funcionarios
);

-- 5 
SELECT *
FROM Produtos
WHERE quantidade_estoque < (
   SELECT AVG(quantidade_estoque)
   FROM Produtos
);

-- 6 
SELECT nome
FROM Clientes
WHERE id_cliente IN (
   SELECT id_cliente
   FROM Vendas
);

-- 7 
SELECT nome
FROM Produtos
WHERE id_produto IN (
   SELECT id_produto
   FROM ItensVenda
);

-- 8 
SELECT nome
FROM Produtos
WHERE id_produto NOT IN (
   SELECT id_produto
   FROM ItensVenda
);

-- 9 
SELECT *
FROM Filiais
WHERE id_filial = (
   SELECT id_filial
   FROM Vendas
   GROUP BY id_filial
   ORDER BY SUM(total) DESC
   LIMIT 1
);

-- 10 
SELECT nome, preco
FROM Produtos
WHERE preco > (
   SELECT AVG(preco)
   FROM Produtos
);
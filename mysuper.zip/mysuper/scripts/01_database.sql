CREATE DATABASE mysuper;

USE mysuper;
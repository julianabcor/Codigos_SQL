-- SELECTS

-- 1
SELECT * FROM Clientes;

-- 2
SELECT nome, telefone FROM Clientes;

-- 3
SELECT * FROM Produtos;

-- 4
SELECT nome, preco FROM Produtos;

-- 5
SELECT * FROM Funcionarios;

-- 6
SELECT nome, cargo FROM Funcionarios;

-- 7.
SELECT * FROM Vendas;

-- 8
SELECT data, total FROM Compras;

-- 9
SELECT descricao, preco FROM Produtos;

-- 10
SELECT * FROM Filiais;

-- 11
SELECT nome, quantidade_estoque FROM Produtos;


-- WHERE

-- 1
SELECT * FROM Clientes WHERE pontos_fidelidade > 100;

-- 2
SELECT * FROM Produtos WHERE preco > 50;

-- 3
SELECT * FROM Funcionarios WHERE salario > 3000;

-- 4
SELECT * FROM Produtos WHERE quantidade_estoque < 10;

-- 5
SELECT * FROM Compras WHERE data = '2025-01-10';

-- 6
SELECT * FROM Clientes WHERE telefone IS NOT NULL;

-- 7
SELECT * FROM Funcionarios WHERE cargo = 'Caixa';

-- 8
SELECT * FROM Produtos WHERE id_filial = 1;

-- 9
SELECT * FROM Vendas WHERE total > 500;

-- 10
SELECT * FROM Fornecedores WHERE nome = 'Distribuidora Alfa';


-- ORDER BY

-- 1.
SELECT * FROM Produtos ORDER BY nome ASC;

-- 2
SELECT * FROM Produtos ORDER BY preco DESC;

-- 3
SELECT * FROM Clientes ORDER BY pontos_fidelidade ASC;

-- 4
SELECT * FROM Funcionarios ORDER BY salario DESC;

-- 5
SELECT * FROM Vendas ORDER BY data DESC;

-- 6
SELECT * FROM Compras ORDER BY total DESC;

-- 7
SELECT * FROM Produtos ORDER BY quantidade_estoque ASC;

-- 8
SELECT * FROM Fornecedores ORDER BY nome ASC;

-- 9
SELECT * FROM Filiais ORDER BY endereco ASC;

-- 10
SELECT * FROM Funcionarios ORDER BY cargo ASC, nome ASC;

-- 11
SELECT * FROM Produtos ORDER BY id_categoria ASC, preco DESC;


-- GROUP BY 

-- 1
SELECT id_categoria, COUNT(*) AS quantidade_produtos FROM Produtos GROUP BY id_categoria;

-- 2
SELECT id_filial, SUM(total) AS soma_total_vendas FROM Vendas GROUP BY id_filial;

-- 3
SELECT id_filial, COUNT(*) AS quantidade_funcionarios FROM Funcionarios GROUP BY id_filial;

-- 4
SELECT id_fornecedor, SUM(total) AS soma_total_compras FROM Compras GROUP BY id_fornecedor;

-- 5
SELECT cargo, AVG(salario) AS media_salarial FROM Funcionarios GROUP BY cargo;

-- 6
SELECT id_funcionario, COUNT(*) AS quantidade_vendas FROM Vendas GROUP BY id_funcionario;

-- 7
SELECT id_fornecedor, COUNT(*) AS quantidade_produtos FROM Produtos GROUP BY id_fornecedor;

-- 8
SELECT endereco, SUM(pontos_fidelidade) AS soma_pontos FROM Clientes GROUP BY endereco;

-- 9
SELECT id_filial, COUNT(*) AS quantidade_compras FROM Compras GROUP BY id_filial;

-- 10
SELECT id_categoria, SUM(quantidade_estoque) AS estoque_total FROM Produtos GROUP BY id_categoria;

-- 11
SELECT cargo, MAX(salario) AS maior_salario FROM Funcionarios GROUP BY cargo;


-- HAVING

-- 1
SELECT id_categoria, COUNT(*) AS quantidade_produtos FROM Produtos GROUP BY id_categoria HAVING COUNT(*) > 5;

-- 2
SELECT id_filial, SUM(total) AS soma_total_vendas FROM Vendas GROUP BY id_filial HAVING SUM(total) > 10000;

-- 3
SELECT cargo, AVG(salario) AS media_salarial FROM Funcionarios GROUP BY cargo HAVING AVG(salario) > 3000;

-- 4
SELECT id_fornecedor, COUNT(*) AS quantidade_produtos FROM Produtos GROUP BY id_fornecedor HAVING COUNT(*) > 10;

-- 5
SELECT id_funcionario, COUNT(*) AS quantidade_vendas FROM Vendas GROUP BY id_funcionario HAVING COUNT(*) > 20;

-- 6
SELECT id_filial, COUNT(*) AS quantidade_funcionarios FROM Funcionarios GROUP BY id_filial HAVING COUNT(*) > 3;

-- 7
SELECT id_categoria, SUM(quantidade_estoque) AS soma_estoque FROM Produtos GROUP BY id_categoria HAVING SUM(quantidade_estoque) > 500;

-- 8
SELECT id_fornecedor, SUM(total) AS soma_total_compras FROM Compras GROUP BY id_fornecedor HAVING SUM(total) > 5000;

-- 9
SELECT data, COUNT(*) AS quantidade_vendas FROM Vendas GROUP BY data HAVING COUNT(*) > 10;

-- 10
SELECT endereco, SUM(pontos_fidelidade) AS soma_pontos FROM Clientes GROUP BY endereco HAVING SUM(pontos_fidelidade) > 200;

-- 11
SELECT cargo, MAX(salario) AS maior_salario FROM Funcionarios GROUP BY cargo HAVING MAX(salario) > 7000;


-- JOINS

-- 1
SELECT p.nome AS nome_produto, c.nome AS nome_categoria 
FROM Produtos p JOIN Categorias c ON p.id_categoria = c.id_categoria;

-- 2
SELECT p.nome AS nome_produto, f.nome AS nome_fornecedor 
FROM Produtos p JOIN Fornecedores f ON p.id_fornecedor = f.id_fornecedor;

-- 3
SELECT fu.nome AS nome_funcionario, fi.nome AS nome_filial 
FROM Funcionarios fu JOIN Filiais fi ON fu.id_filial = fi.id_filial;

-- 4
SELECT v.id_venda, v.data, c.nome AS nome_cliente 
FROM Vendas v JOIN Clientes c ON v.id_cliente = c.id_cliente;

-- 5
SELECT c.id_compra, c.data, f.nome AS nome_fornecedor 
FROM Compras c JOIN Fornecedores f ON c.id_fornecedor = f.id_fornecedor;

-- 6
SELECT iv.id_venda, p.nome AS nome_produto, iv.quantidade, iv.subtotal 
FROM ItensVenda iv JOIN Produtos p ON iv.id_produto = p.id_produto;

-- 7
SELECT p.nome AS nome_produto, f.nome AS nome_filial 
FROM Produtos p JOIN Filiais f ON p.id_filial = f.id_filial;

-- 8
SELECT v.id_venda, f.nome AS nome_funcionario 
FROM Vendas v JOIN Funcionarios f ON v.id_funcionario = f.id_funcionario;

-- 9
SELECT c.id_compra, f.nome AS nome_filial, c.total 
FROM Compras c JOIN Filiais f ON c.id_filial = f.id_filial;

-- 10
SELECT c.nome AS nome_cliente, v.id_venda, v.total 
FROM Clientes c JOIN Vendas v ON c.id_cliente = v.id_cliente;

-- 11
SELECT v.id_venda, c.nome AS nome_cliente, f.nome AS nome_funcionario, fi.nome AS nome_filial, v.total 
FROM Vendas v 
JOIN Clientes c ON v.id_cliente = c.id_cliente
JOIN Funcionarios f ON v.id_funcionario = f.id_funcionario
JOIN Filiais fi ON v.id_filial = fi.id_filial;